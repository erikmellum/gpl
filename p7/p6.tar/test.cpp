#include "expr.h"
#include <iostream>
#include <string>
using namespace std;

int main()
{
    string c = .25 && .1;
    cout << c << endl;
}
